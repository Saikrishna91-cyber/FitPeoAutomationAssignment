import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import java.util.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;


public class FitPeoAutomationTest {
    public static void main(String[] args){
                // Set up WebDriver
                WebDriverManager.chromedriver().setup();
                WebDriver driver = new ChromeDriver();

                try {
                    // Navigate to FitPeo homepage
                    driver.get("https://fitpeo.com/home");
                    driver.manage().window().maximize();

                    // Initialize WebDriverWait
                    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

                    // Navigate to the Revenue Calculator page
                    WebElement revenueCalculatorLink = driver.findElement(By.linkText("Revenue Calculator"));
                    revenueCalculatorLink.click();

                    // Wait for the slider to be visible
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'MuiBox-root css-j7qwjs']/span[1]//span[3]/input")));

                    // Scroll down to reveal the slider
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

                    // Locate the slider element
                    WebElement sliderElement = driver.findElement(By.xpath("//div[@class = 'MuiBox-root css-j7qwjs']/span[1]//span[3]/input"));

                    Thread.sleep(2000);
                    // Set the slider to 820 using JavaScript
                    js.executeScript("arguments[0].value=820;", sliderElement);
                    //System.out.println("Slider value set to: 820");

                    // waiting for Medicare Eligible Patients
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type = 'number']")));

                    // Locate the text field associated with the slider and set its value to 560
                    WebElement textField = driver.findElement(By.xpath("//input[@type = 'number']"));

                    js.executeScript("arguments[0].value = '560'",sliderElement);


                    // Wait for the slider to adjust based on the new value
                    wait.until(ExpectedConditions.attributeToBe(sliderElement,"value","560"));

                    //Validate that the slider's value has updated to 560
                    String sliderValue = sliderElement.getAttribute("value");
                    System.out.println("Updated slider value: " + sliderValue);


                    if (!sliderValue.equals("560")) {
                        System.out.println("Error: Slider did not update correctly.");
                    } else {
                        System.out.println("Slider correctly updated to 560.");
                    }



                    js.executeScript("arguments[0],value='820';",sliderElement);

                    // Scroll down further to locate and select the CPT codes checkboxes
                    js.executeScript("window.scrollBy(0,document.body.scrolldown);");
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class = 'MuiBox-root css-1p19z09']/div//p")));

                    // Select checkboxes for CPT-99091, CPT-99453, CPT-99454, and CPT-99474
                    WebElement checkbox1 = driver.findElement(By.xpath("//div[@class = 'MuiBox-root css-1p19z09']/div[1]/label[1]//input"));
                    js.executeScript("arguments[0].click();", checkbox1);
                    WebElement checkbox2 = driver.findElement(By.xpath("//div[@class = 'MuiBox-root css-1p19z09']/div[2]/label[1]//input"));
                    js.executeScript("arguments[0].click();", checkbox2);
                    WebElement checkbox3 = driver.findElement(By.xpath("//div[@class = 'MuiBox-root css-1p19z09']/div[3]/label[1]//input"));
                    js.executeScript("arguments[0].click();", checkbox3);
                    WebElement checkbox4 = driver.findElement(By.xpath("//div[@class = 'MuiBox-root css-1p19z09']/div[8]/label[1]//input"));
                    js.executeScript("arguments[0].click();", checkbox4);


                    js.executeScript("window.scrollBy(0,document.body.scrolltop)");
                    // Validate the Total Recurring Reimbursement
                    WebElement totalReimbursementElement = driver.findElement(By.xpath("//div[@class =  'MuiBox-root css-m1khva']/p[2]"));
                    String totalReimbursement = totalReimbursementElement.getText();
                    System.out.println("Total Recurring Reimbursement: " + totalReimbursement);

                    if (totalReimbursement.contains("$110700")) {
                        System.out.println("Total Recurring Reimbursement validated: $110700");
                    } else {
                        System.out.println("Error: Total Recurring Reimbursement value is incorrect.");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    //Close the browser
                    //driver.quit();
                }

    }
}
